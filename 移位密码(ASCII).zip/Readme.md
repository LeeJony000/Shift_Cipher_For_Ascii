# #移位密码（Shift_Cipher_For_Ascii）

+ 基于Ascii码进行的移位操作，定义域与值域为：ASCII码表上所有字符，空格符可选择是否需要进行加密或解密操作
+ 将压缩包下载到本地，运行Shift_Cipher_For_Ascii.py即可
+ Windows和Linux操作系统运行时有Shift_Cipher的Logo设计

